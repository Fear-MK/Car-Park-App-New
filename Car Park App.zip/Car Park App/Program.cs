﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using Newtonsoft.Json;
using System.Collections;
using static cogs;


namespace Car_Park_App
{
    internal class Program
    {
        static void Reset() //This is just a class to make the rest of the code a little more clear
        {
            Console.Clear();
            Console.WriteLine("####################################################\n\n  W E L C O M E   T O   B O B ' S   C A R   P A R K\n\n####################################################");
        }

        static void Main()
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Black; // It is inefficient to add this to Reset
            Reset();

            Thread.Sleep(500); //Pausescode execution for 1000 milliseconds
            string reg_plate;
            while (true) // Simple Validation
            {
                Console.WriteLine("\nPlease enter the car registration: ");
                reg_plate = Console.ReadLine().ToUpper();
                Console.WriteLine("Registration entered: " +reg_plate+" \n\nIs this correct? (y/n)");
                try
                {
                    char reg_plate_confimation = char.Parse(Console.ReadLine());
                    if (reg_plate_confimation == 'y')
                    {
                        break;
                    }
                    Thread.Sleep(1000);
                }
                catch
                {
                    Console.WriteLine("\nInvalid data entered.");
                    Thread.Sleep(1000);
                }
            }
            Reset(); //Clears screen ready for the parking options

            (Dictionary<int, int>, string[]) menu_tuple = cogs.DisplayMenu();
            Dictionary <int, int> dictionary = menu_tuple.Item1;
            string[] times = menu_tuple.Item2;
            int choice = 0;

            while (true)
            {
                try
                {
                    choice = int.Parse(Console.ReadLine());
                    if (choice < 1 || choice > dictionary.Count)
                    {
                        Console.WriteLine("Invalid entry, please enter a valid option (1-" + dictionary.Count + ")");
                    }
                    else
                    {
                        Reset();
                        Console.WriteLine("{0} selected. ");
                        break;
                    }
                }
                catch
                {
                    Console.WriteLine("Invalid entry, please enter a valid option (1-" + dictionary.Count + ")");
                }
            }

            float price = dictionary[choice];
            float paid = 0;

            while (true)
            {
                Console.Write("Amount Due: {0:C2}\nPlease enter insert coins below.", price);
                try
                {
                    paid = paid + float.Parse(Console.ReadLine());

                }
                catch
                {
                    Console.WriteLine("Invalid coin amount entered (symbol not necessary, please try again. (Press any key to retry)");
                    Console.ReadKey();
                    Reset();
                }

                Console.WriteLine("Amount Entered: {0:C2}", price);
                if (price - paid <= 0)
                {
                    Console.WriteLine("Amount inserted: {0:C2}", paid);
                    Thread.Sleep(500);
                    Console.WriteLine("Change needed: {0:C2}", (price - paid) * -1);
                    Thread.Sleep(1500);
                    cogs.PrintTicket();
                    Main();
                }
                else
                {
                    Reset();
                }
            }




        }
    }
}
