﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using Newtonsoft.Json;
using System.Collections;

public class cogs
{
    internal static (Dictionary<int, int>, string[]) DisplayMenu()
    {
        Dictionary<int, int> dictionary = new Dictionary<int, int>(); //This upcoming section is making the dictionary from the menu.txt, so that any modifications made in the "management mode" will be saved for when the program loads up again.
        List<string> lines = null;

        try
        {
            lines = File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), "menu.txt")).ToList();
        }
        catch
        {
            Console.WriteLine("Could not find menu.txt, please create one.");
            Environment.Exit(400);
        }

        List<string> times = new List<string>();
        int count1 = 0;

        foreach (string line in lines ?? new List<string>())
        {
            count1++;
            string[] parts = line.Split('=');
            times.Add(parts[0]);
            dictionary.Add(count1, int.Parse(parts[1]));
            string menu_before_spaces = string.Concat("{0}      {1}£{2}", count1.ToString(), parts[0], parts[1]);
            int Length = string.Concat("{0}      {1}£{2}", count1.ToString(), parts[0], parts[1]).Length;

            int number_of_spaces = 40 - Length;
            string spaces = "";
            for (int i = 0; i < number_of_spaces; i++)
            {
                spaces += " ";
            }

            Console.WriteLine("{0}      {1}{2}£{2}", count1, parts[0], spaces, parts[1]);
        }


        Console.WriteLine("\nPlease select duration:       (Press number 1-" + dictionary.Count + ")\n");
        return (dictionary, times.ToArray());
    }
    internal static void PrintTicket(string registration, float fee, float change) //needs expiry and date entered etc
    {
        Console.Clear();
        Console.WriteLine("Printing ticket");
        for (int i = 0;i <= 3;i++)
        {
            Thread.Sleep(400);
            Console.Write(". ");
        }
        Console.BackgroundColor = ConsoleColor.White;
        string ticket_text = TicketTextGen(registration, fee, change);
        text("                             ");
        Thread.Sleep(100);
        Console.WriteLine("  B O B ' S  C A R  P A R K  ");
        Thread.Sleep(100);
        Console.WriteLine("                             ");


    }

    internal static string TicketTextGen(string registration, float fee, float change)
    {
        string output = "                             \n  B O B ' S  C A R  P A R K  \n\n\nRegistration: {0}\n\nEntry Time: {1}"; 
    }
}
